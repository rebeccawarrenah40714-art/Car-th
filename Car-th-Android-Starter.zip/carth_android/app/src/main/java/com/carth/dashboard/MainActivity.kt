package com.carth.dashboard

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val Navy = Color(0xFF061426)
private val Panel = Color(0xCC09243D)
private val Cyan = Color(0xFF45D8FF)
private val White = Color(0xFFF3F8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setContent { CarthApp() }
    }
}

@Composable
fun CarthApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("carth", Context.MODE_PRIVATE) }
    var futuristic by remember { mutableStateOf(prefs.getBoolean("futuristic", false)) }
    var showSettings by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }
    var carName by remember { mutableStateOf(prefs.getString("car", "TOYOTA") ?: "TOYOTA") }
    var unit by remember { mutableStateOf(prefs.getString("unit", "كم/س") ?: "كم/س") }
    var showClock by remember { mutableStateOf(prefs.getBoolean("clock", true)) }
    var dim by remember { mutableFloatStateOf(prefs.getFloat("dim", .12f)) }
    var wallpaper by remember { mutableIntStateOf(prefs.getInt("wall", 0)) }
    var customImage by remember { mutableStateOf(prefs.getString("image", null)) }
    var speed by remember { mutableIntStateOf(0) }
    var sections by remember { mutableStateOf(prefs.getString("sections", "speed,clock,trip,prayer,music,apps")!!.split(",").filter { it.isNotBlank() }) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { customImage = it.toString(); prefs.edit().putString("image", it.toString()).apply() }
    }
    val colors = listOf(Color(0xFF062747), Color(0xFF10233D), Color(0xFF142D28), Color(0xFF241B3C), Color(0xFF332016), Color(0xFF111820))
    val backgrounds = listOf("غابة ليلية", "أزرق عميق", "زمردي", "بنفسجي", "كهرماني", "فحمي")
    val bg = colors[wallpaper.coerceIn(0, colors.lastIndex)]

    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Cyan, onBackground = White, onSurface = White)) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(bg, Navy, Color(0xFF020811))))) {
            val wide = maxWidth > 850.dp
            val compact = maxWidth < 600.dp
            // Contrast veil controlled by the background dim slider.
            val uploadedBitmap by produceState<android.graphics.Bitmap?>(initialValue = null, customImage) {
                value = try { customImage?.let { context.contentResolver.openInputStream(Uri.parse(it))?.use(BitmapFactory::decodeStream) } } catch (_: Exception) { null }
            }
            if (uploadedBitmap != null) {
                Image(uploadedBitmap!!.asImageBitmap(), contentDescription = "خلفية مخصصة", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
            }
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            Column(Modifier.fillMaxSize().padding(if (compact) 10.dp else 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "الإعدادات", tint = Cyan) }
                        Text("Car-th", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(.5f))) {
                            Text("☀ 31°  |  مشمس", Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = White, fontSize = 13.sp)
                        }
                        IconButton(onClick = { futuristic = !futuristic; prefs.edit().putBoolean("futuristic", futuristic).apply() }) {
                            Icon(Icons.Default.AutoAwesome, "تبديل التصميم", tint = Cyan)
                        }
                    }
                }
                if (wide) {
                    Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if ("clock" in sections && showClock) ClockCard()
                            if ("trip" in sections) InfoCard("ملخص الرحلة", "المسافة  0.4 كم", "مدة القيادة  1 دقيقة", Icons.Default.Route)
                            if ("prayer" in sections) InfoCard("أوقات الصلاة", "العشاء  7:14 م", "الصلاة القادمة حسب مدينتك", Icons.Default.Notifications)
                        }
                        Box(Modifier.weight(1.65f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            if ("speed" in sections) SpeedCard(speed, unit, futuristic)
                        }
                        Column(Modifier.weight(.8f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            InfoCard(carName, "متصل بالنظام", "وضع القيادة", Icons.Default.DirectionsCar)
                            if ("music" in sections) MusicCard()
                        }
                    }
                } else {
                    Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if ("clock" in sections && showClock) ClockCard()
                            if ("trip" in sections) InfoCard("ملخص الرحلة", "0.4 كم", "مدة القيادة 1 دقيقة", Icons.Default.Route)
                            if ("prayer" in sections) InfoCard("أوقات الصلاة", "العشاء 7:14 م", "الصلاة القادمة", Icons.Default.Notifications)
                        }
                        Box(Modifier.weight(1.35f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            if ("speed" in sections) SpeedCard(speed, unit, futuristic)
                        }
                    }
                }
                if ("music" in sections || "apps" in sections) {
                    Surface(Modifier.fillMaxWidth(), color = Panel, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(.35f))) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            if ("music" in sections) MusicCard(Modifier.weight(1f))
                            if ("apps" in sections) Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                AppShortcut(Icons.Default.Radio, "الراديو")
                                AppShortcut(Icons.Default.MusicNote, "الموسيقى")
                                AppShortcut(Icons.Default.GridView, "التطبيقات")
                                AppShortcut(Icons.Default.Map, "الخرائط")
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { showEditor = true }) { Icon(Icons.Default.Tune, null); Spacer(Modifier.width(6.dp)); Text("تحرير أقسام الشاشة") }
                }
            }
            if (showSettings) SettingsDialog(
                onDismiss = { showSettings = false }, futuristic = futuristic,
                onStyle = { futuristic = it; prefs.edit().putBoolean("futuristic", it).apply() },
                carName = carName, onCarName = { carName = it; prefs.edit().putString("car", it).apply() },
                unit = unit, onUnit = { unit = it; prefs.edit().putString("unit", it).apply() },
                showClock = showClock, onClock = { showClock = it; prefs.edit().putBoolean("clock", it).apply() },
                dim = dim, onDim = { dim = it; prefs.edit().putFloat("dim", it).apply() },
                wallpaper = wallpaper, backgrounds = backgrounds, onWallpaper = { wallpaper = it; prefs.edit().putInt("wall", it).apply() },
                onUpload = { imagePicker.launch("image/*") }, onReset = { prefs.edit().clear().apply(); futuristic = false; carName = "TOYOTA"; unit = "كم/س"; showClock = true; dim = .12f; wallpaper = 0; sections = listOf("speed","clock","trip","prayer","music","apps") }
            )
            if (showEditor) EditorDialog(sections, onDismiss = { showEditor = false }, onSave = { sections = it; prefs.edit().putString("sections", it.joinToString(",")).apply() })
        }
    }
}

@Composable fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(.32f))) {
        Column(Modifier.fillMaxSize(), content = content)
    }
}

@Composable fun ClockCard() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); kotlinx.coroutines.delay(1000) } }
    val time = SimpleDateFormat("hh:mm", Locale("ar")).format(now)
    val date = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).format(now)
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(time, color = White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(date, color = White.copy(.75f), fontSize = 12.sp)
        }
    }
}

@Composable fun InfoCard(title: String, line1: String, line2: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)); Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            Text(line1, color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(line2, color = White.copy(.7f), fontSize = 11.sp)
        }
    }
}

@Composable fun SpeedCard(speed: Int, unit: String, futuristic: Boolean) {
    GlassCard(Modifier.fillMaxWidth().fillMaxHeight()) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
            val diameter = minOf(maxWidth, maxHeight)
            Canvas(Modifier.size(diameter)) {
                val r = size.minDimension * .43f
                val center = Offset(size.width / 2, size.height / 2)
                drawArc(Cyan.copy(.85f), 135f, 270f, false, topLeft = Offset(center.x-r, center.y-r), size = androidx.compose.ui.geometry.Size(r*2,r*2), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                for (i in 0..26) {
                    val angle = Math.toRadians((135 + i * (270.0 / 26.0)))
                    val inner = r * if (i % 2 == 0) .88f else .93f
                    val outer = r
                    drawLine(Cyan.copy(if (i % 2 == 0) .9f else .45f), Offset(center.x + cos(angle).toFloat()*inner, center.y + sin(angle).toFloat()*inner), Offset(center.x + cos(angle).toFloat()*outer, center.y + sin(angle).toFloat()*outer), strokeWidth = if (i % 2 == 0) 2.dp.toPx() else 1.dp.toPx())
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(if (futuristic) "DRIVE" else "عداد السرعة", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                Text(speed.toString(), color = White, fontSize = 52.sp, fontWeight = FontWeight.Light)
                Text(unit, color = White.copy(.8f), fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Icon(Icons.Default.DirectionsCar, null, tint = Cyan, modifier = Modifier.size(44.dp))
            }
        }
    }
}

@Composable fun MusicCard(modifier: Modifier = Modifier) {
    Row(modifier.padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(Icons.Default.GraphicEq, null, tint = Cyan)
        Column(Modifier.weight(1f)) { Text("مشغل الموسيقى", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold); Text("اختر مصدراً للصوت", color = White.copy(.65f), fontSize = 10.sp) }
        Icon(Icons.Default.SkipPrevious, null, tint = White)
        Icon(Icons.Default.PlayCircle, null, tint = Cyan, modifier = Modifier.size(30.dp))
        Icon(Icons.Default.SkipNext, null, tint = White)
    }
}

@Composable fun AppShortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(Modifier.clickable { }.padding(horizontal = 5.dp, vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(22.dp)); Text(label, color = White, fontSize = 10.sp) }
}

@Composable fun SettingsDialog(onDismiss: () -> Unit, futuristic: Boolean, onStyle: (Boolean)->Unit, carName: String, onCarName: (String)->Unit, unit: String, onUnit: (String)->Unit, showClock: Boolean, onClock: (Boolean)->Unit, dim: Float, onDim: (Float)->Unit, wallpaper: Int, backgrounds: List<String>, onWallpaper: (Int)->Unit, onUpload: ()->Unit, onReset: ()->Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Color(0xFF0A2035), title = { Text("إعدادات Car-th", color = White) }, text = {
        Column(Modifier.fillMaxWidth().heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("نمط الواجهة", color = Cyan)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = !futuristic, onClick = { onStyle(false) }, label = { Text("كلاسيكي") }); FilterChip(selected = futuristic, onClick = { onStyle(true) }, label = { Text("مستقبلي") }) }
            Divider(color = Cyan.copy(.25f))
            Text("الخلفيات", color = Cyan)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(backgrounds.indices.toList()) { i -> FilterChip(selected = wallpaper == i, onClick = { onWallpaper(i) }, label = { Text(backgrounds[i]) }) } }
            OutlinedButton(onClick = onUpload, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(6.dp)); Text("رفع خلفية من الجهاز") }
            Text("تعتيم الخلفية", color = White)
            Slider(value = dim, onValueChange = onDim, valueRange = 0f..0.75f)
            OutlinedTextField(value = carName, onValueChange = onCarName, label = { Text("اسم السيارة") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) { Text("وحدة السرعة", color = White); Row { FilterChip(selected = unit == "كم/س", onClick = { onUnit("كم/س") }, label = { Text("كم/س") }); Spacer(Modifier.width(5.dp)); FilterChip(selected = unit == "mph", onClick = { onUnit("mph") }, label = { Text("mph") }) } }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("إظهار الساعة", color = White); Spacer(Modifier.weight(1f)); Switch(checked = showClock, onCheckedChange = onClock) }
            TextButton(onClick = onReset) { Text("استعادة الإعدادات الافتراضية", color = Color(0xFFFF9B9B)) }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("تم") } })
}

@Composable fun EditorDialog(current: List<String>, onDismiss: ()->Unit, onSave: (List<String>)->Unit) {
    val labels = mapOf("speed" to "عداد السرعة", "clock" to "الساعة والتاريخ", "trip" to "ملخص الرحلة", "prayer" to "أوقات الصلاة", "music" to "مشغل الموسيقى", "apps" to "شريط التطبيقات")
    var items by remember { mutableStateOf(current) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Color(0xFF0A2035), title = { Text("محرر أقسام الشاشة", color = White) }, text = {
        Column(Modifier.heightIn(max = 480.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("فعّل الأقسام التي تريد عرضها، واستخدم الأسهم لتغيير ترتيبها.", color = White.copy(.7f), fontSize = 12.sp)
            labels.forEach { (id, label) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = id in items, onCheckedChange = { checked -> items = if (checked) items + id else items - id })
                    Text(label, color = White, modifier = Modifier.weight(1f))
                    val index = items.indexOf(id)
                    IconButton(enabled = index > 0, onClick = { val list = items.toMutableList(); val a = list[index-1]; list[index-1] = list[index]; list[index] = a; items = list }) { Icon(Icons.Default.KeyboardArrowUp, null, tint = Cyan) }
                    IconButton(enabled = index >= 0 && index < items.lastIndex, onClick = { val list = items.toMutableList(); val a = list[index+1]; list[index+1] = list[index]; list[index] = a; items = list }) { Icon(Icons.Default.KeyboardArrowDown, null, tint = Cyan) }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { onSave(items); onDismiss() }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}
